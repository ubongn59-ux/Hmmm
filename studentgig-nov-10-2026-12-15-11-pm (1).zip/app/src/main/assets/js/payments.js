// Moniepoint Manual Payment & Submission Controller for StudentGig

let activeReviewInterval = null;

async function initPaymentsPage() {
  // Load dynamic Moniepoint bank details from platform_settings
  await loadMoniepointDetails();

  // If user is logged in, show their submission history & 24h countdowns
  Auth.init(async (user) => {
    if (user) {
      loadUserPaymentSubmissions(user.uid);
    }
  });

  // Check URL params for prefilled deposit amount
  const urlParams = new URLSearchParams(window.location.search);
  const amountParam = urlParams.get("amount");
  const refParam = urlParams.get("desc");
  if (amountParam && document.getElementById("payAmount")) {
    document.getElementById("payAmount").value = amountParam;
  }
}

async function loadMoniepointDetails() {
  const accountNameEl = document.getElementById("moniepointAccountName");
  const bankNameEl = document.getElementById("moniepointBankName");
  const accountNumberEl = document.getElementById("moniepointAccountNumber");
  const instructionsEl = document.getElementById("moniepointInstructions");

  try {
    const settings = await DB.getPlatformSettings();
    if (accountNameEl) accountNameEl.textContent = settings.moniepointAccountName || "STUDENTGIG NIGERIA";
    if (bankNameEl) bankNameEl.textContent = settings.moniepointBankName || "Moniepoint Microfinance Bank";
    if (accountNumberEl) accountNumberEl.textContent = settings.moniepointAccountNumber || "8123456789";
    if (instructionsEl) instructionsEl.textContent = settings.paymentInstructions || "";
  } catch (e) {
    console.error("Error loading Moniepoint details:", e);
  }
}

function copyAccountNumber() {
  const num = document.getElementById("moniepointAccountNumber")?.textContent;
  if (num) {
    navigator.clipboard.writeText(num).then(() => {
      alert("Moniepoint Account Number copied: " + num);
    }).catch(() => {
      alert("Account: " + num);
    });
  }
}

// Payment Proof Submission Form
async function handlePaymentProofSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("submitProofBtn");
  const alertBox = document.getElementById("paymentAlert");
  alertBox.innerHTML = "";

  const user = Auth.currentUser;
  const profile = Auth.userProfile;
  if (!user) {
    alert("Please log in to submit payment proof.");
    window.location.href = "login.html";
    return;
  }

  const amount = Number(document.getElementById("payAmount").value);
  const payerName = document.getElementById("payPayerName").value.trim();
  const transactionRef = document.getElementById("payReference").value.trim();
  const paymentDate = document.getElementById("payDate").value;
  const screenshotInput = document.getElementById("payScreenshot");

  if (!amount || amount < 100) {
    alertBox.innerHTML = `<div class="alert alert-error">Please enter the valid amount paid in Naira (min ₦100).</div>`;
    return;
  }
  if (!payerName || payerName.length < 2) {
    alertBox.innerHTML = `<div class="alert alert-error">Please enter the exact sender name on your bank receipt.</div>`;
    return;
  }
  if (!transactionRef || transactionRef.length < 4) {
    alertBox.innerHTML = `<div class="alert alert-error">Please enter the Moniepoint/Bank transaction reference session ID.</div>`;
    return;
  }
  if (!screenshotInput.files || !screenshotInput.files[0]) {
    alertBox.innerHTML = `<div class="alert alert-error">Please attach a clear screenshot or receipt image of the payment.</div>`;
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Uploading Evidence...`;

  try {
    const file = screenshotInput.files[0];
    const screenshotDataUrl = await readFileAsDataURL(file);

    const paymentData = {
      userId: user.uid,
      userName: profile?.fullName || user.displayName || "User",
      userEmail: user.email,
      amount: amount,
      payerName: payerName,
      transactionRef: transactionRef,
      paymentDate: paymentDate || new Date().toISOString().split('T')[0],
      screenshotUrl: screenshotDataUrl
    };

    await DB.submitPayment(paymentData);

    // Prompt requested specific message
    alertBox.innerHTML = `
      <div class="alert alert-success" style="flex-direction: column;">
        <div style="font-weight: 700; margin-bottom: 4px;">Payment Submitted Successfully!</div>
        <div>Your payment has been submitted successfully. Our administration team will review your payment within 24 hours. You will receive a notification once the verification process is complete.</div>
      </div>
    `;

    // Clear form
    document.getElementById("paymentProofForm").reset();

    // Reload submissions
    loadUserPaymentSubmissions(user.uid);

    btn.disabled = false;
    btn.innerHTML = `Submit Payment Evidence`;
  } catch (err) {
    alertBox.innerHTML = `<div class="alert alert-error">Failed to submit payment: ${err.message}</div>`;
    btn.disabled = false;
    btn.innerHTML = `Submit Payment Evidence`;
  }
}

// Render User's Submitted Payments & 24h Countdown
async function loadUserPaymentSubmissions(userId) {
  const container = document.getElementById("userSubmissionsList");
  if (!container) return;

  try {
    const payments = await DB.getUserPayments(userId);
    if (payments.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🧾</div>
          <div class="empty-title">No submitted payments</div>
          <div class="empty-desc">When you transfer to the official Moniepoint account and submit proof, it will appear here.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = payments.map(p => {
      const isPending = p.status === 'Pending Review';
      const deadlineDate = p.reviewDeadline?.toDate ? p.reviewDeadline.toDate() : new Date(p.reviewDeadline);
      const isOverdue = isPending && deadlineDate && Date.now() > deadlineDate.getTime();

      let statusBadge = '';
      if (p.status === 'Approved') {
        statusBadge = '<span class="badge badge-approved">Approved ✓</span>';
      } else if (p.status === 'Rejected') {
        statusBadge = '<span class="badge badge-rejected">Rejected ✗</span>';
      } else if (isOverdue) {
        statusBadge = '<span class="badge badge-overdue">Review Overdue</span>';
      } else {
        statusBadge = '<span class="badge badge-pending">Pending Review</span>';
      }

      return `
        <div class="card card-hover" style="margin-bottom: 12px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div>
              <div style="font-weight: 700; font-size: 1.1rem; color: var(--secondary);">${formatNaira(p.amount)}</div>
              <div style="font-size: 0.8rem; color: var(--text-muted);">Ref: ${p.transactionRef} • ${formatDate(p.createdAt)}</div>
            </div>
            ${statusBadge}
          </div>

          ${isPending ? `
            <div class="review-timer-card" style="padding: 10px 14px; margin: 10px 0 6px 0;">
              <div class="review-timer-icon" style="font-size: 1.4rem;">⏳</div>
              <div class="review-timer-info">
                <div class="review-timer-title" style="font-size: 0.82rem;">24-Hour Review Target</div>
                <div class="review-timer-countdown countdown-ticker" data-target="${deadlineDate?.getTime() || 0}" style="font-size: 0.95rem;">
                  Calculating...
                </div>
              </div>
            </div>
          ` : ''}

          ${p.status === 'Rejected' && p.rejectionReason ? `
            <div class="alert alert-error" style="margin-top: 10px; font-size: 0.82rem; padding: 8px 12px;">
              <strong>Reason:</strong> ${p.rejectionReason}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');

    // Start 24h countdown ticker
    startCountdownTickers();
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">Error loading payments history.</div>`;
  }
}

function startCountdownTickers() {
  if (activeReviewInterval) clearInterval(activeReviewInterval);

  function updateTickers() {
    document.querySelectorAll(".countdown-ticker").forEach(el => {
      const targetTime = Number(el.getAttribute("data-target"));
      if (!targetTime) return;

      const remaining = targetTime - Date.now();
      if (remaining <= 0) {
        el.textContent = "24h passed - Flagged Overdue for Admin";
        el.style.color = "#dc2626";
      } else {
        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const mins = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((remaining % (1000 * 60)) / 1000);
        el.textContent = `${hours.toString().padStart(2, '0')}h : ${mins.toString().padStart(2, '0')}m : ${secs.toString().padStart(2, '0')}s remaining`;
      }
    });
  }

  updateTickers();
  activeReviewInterval = setInterval(updateTickers, 1000);
}
