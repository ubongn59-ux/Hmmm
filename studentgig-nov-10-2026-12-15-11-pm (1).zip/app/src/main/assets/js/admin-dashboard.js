// Administrator Dashboard Analytics & Overview Module

document.addEventListener("DOMContentLoaded", () => {
  AdminAuth.requireAdminAuth("admin-login.html");

  window.addEventListener('adminReady', (e) => {
    loadAdminAnalytics();
  });
});

async function loadAdminAnalytics() {
  try {
    // 1. Fetch Users
    const usersSnap = await db.collection(DB.USERS).get();
    const users = usersSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const totalUsers = users.length;
    const suspendedUsers = users.filter(u => u.isSuspended).length;
    const activeUsers = totalUsers - suspendedUsers;

    // 2. Fetch Gigs
    const gigsSnap = await db.collection(DB.GIGS).get();
    const totalGigs = gigsSnap.size;

    // 3. Fetch Jobs
    const jobsSnap = await db.collection(DB.JOBS).get();
    const jobs = jobsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const totalJobs = jobs.length;
    const completedJobs = jobs.filter(j => j.status === 'completed').length;

    // 4. Fetch Payments
    const paymentsSnap = await db.collection(DB.PAYMENTS).get();
    const payments = paymentsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    const pendingPayments = payments.filter(p => p.status === 'Pending Review');
    const approvedPayments = payments.filter(p => p.status === 'Approved');
    const rejectedPayments = payments.filter(p => p.status === 'Rejected');

    // Overdue review payments (pending where deadline < now)
    const now = Date.now();
    const overdueCount = pendingPayments.filter(p => {
      const deadline = p.reviewDeadline?.toDate ? p.reviewDeadline.toDate() : new Date(p.reviewDeadline);
      return deadline && deadline.getTime() < now;
    }).length;

    // Total Verified Payment Volume
    const totalVerifiedAmount = approvedPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

    // Update DOM
    setStat("admTotalUsers", totalUsers);
    setStat("admActiveUsers", activeUsers);
    setStat("admSuspendedUsers", suspendedUsers);
    setStat("admTotalGigs", totalGigs);
    setStat("admTotalJobs", totalJobs);
    setStat("admCompletedJobs", completedJobs);
    setStat("admPendingPayments", pendingPayments.length);
    setStat("admApprovedPayments", approvedPayments.length);
    setStat("admRejectedPayments", rejectedPayments.length);
    setStat("admOverduePayments", overdueCount);
    setStat("admVerifiedAmount", formatNaira(totalVerifiedAmount));

    // Overdue alert banner
    const overdueAlert = document.getElementById("adminOverdueAlert");
    if (overdueAlert) {
      if (overdueCount > 0) {
        overdueAlert.style.display = "flex";
        overdueAlert.innerHTML = `
          <strong>⚠️ Immediate Attention Required:</strong> ${overdueCount} payment submission(s) have exceeded the 24-hour review target. Please inspect and verify.
          <a href="admin-payments.html" class="btn btn-danger btn-sm" style="margin-left:auto;">Review Now</a>
        `;
      } else {
        overdueAlert.style.display = "none";
      }
    }

    // Populate Recent Activity Table
    renderRecentAuditLogs();
  } catch (err) {
    console.error("Admin analytics error:", err);
  }
}

function setStat(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

async function renderRecentAuditLogs() {
  const container = document.getElementById("adminRecentLogsTable");
  if (!container) return;

  try {
    const logsSnap = await db.collection(DB.ADMIN_LOGS)
      .limit(8)
      .get();
    let logs = logsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    logs.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));

    if (logs.length === 0) {
      container.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#94a3b8;">No administrative events recorded yet.</td></tr>`;
      return;
    }

    container.innerHTML = logs.map(l => `
      <tr>
        <td style="color:#10b981;font-weight:600;">${l.action || 'EVENT'}</td>
        <td>${l.adminEmail || 'Admin'}</td>
        <td>${l.details || 'Action completed'}</td>
        <td style="color:#94a3b8;">${formatDate(l.timestamp)}</td>
      </tr>
    `).join('');
  } catch (e) {
    container.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#ef4444;">Unable to load audit logs.</td></tr>`;
  }
}
