// Separate Administrator Authentication & Protection Module
// Strict authorization: normal users can never access admin panels

const AdminAuth = {
  currentAdmin: null,

  // Designated Platform Administrators
  AUTHORIZED_ADMIN_EMAILS: [
    "ubongn59@gmail.com",
    "admin@studentgig.ng",
    "admin@studentgig11.firebaseapp.com"
  ],

  // Check if a user has verified administrator privileges
  async isUserAdmin(user) {
    if (!user || !user.email) return false;
    const email = user.email.toLowerCase();

    // 1. Direct whitelist match
    if (this.AUTHORIZED_ADMIN_EMAILS.includes(email)) {
      return true;
    }

    // 2. Check dedicated admin_users collection in Firestore
    try {
      const adminDoc = await db.collection('admin_users').doc(user.uid).get();
      if (adminDoc.exists && adminDoc.data().active === true) {
        return true;
      }
    } catch (e) {
      console.warn("Admin check query note:", e);
    }

    return false;
  },

  // Protect Admin Pages
  requireAdminAuth(redirectPage = "admin-login.html") {
    auth.onAuthStateChanged(async (user) => {
      if (!user) {
        window.location.href = redirectPage;
        return;
      }
      const hasPrivileges = await this.isUserAdmin(user);
      if (!hasPrivileges) {
        alert("ACCESS DENIED: You do not have administrator credentials for StudentGig.");
        await auth.signOut();
        window.location.href = redirectPage;
      } else {
        this.currentAdmin = user;
        const event = new CustomEvent('adminReady', { detail: { admin: user } });
        window.dispatchEvent(event);
      }
    });
  },

  // Admin Login
  async loginAdmin(email, password) {
    if (!email || !password) {
      throw new Error("Enter administrator email and password.");
    }

    const userCredential = await auth.signInWithEmailAndPassword(email.trim(), password);
    const user = userCredential.user;

    const hasPrivileges = await this.isUserAdmin(user);
    if (!hasPrivileges) {
      await auth.signOut();
      throw new Error("Access denied: This email is not authorized as a platform administrator.");
    }

    // Record admin session sign-in
    try {
      await db.collection(DB.ADMIN_LOGS).add({
        adminEmail: user.email,
        action: "ADMIN_LOGIN",
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      });
    } catch (e) {}

    return user;
  },

  // Admin Logout
  async logoutAdmin() {
    if (auth) {
      await auth.signOut();
      window.location.href = "admin-login.html";
    }
  }
};
