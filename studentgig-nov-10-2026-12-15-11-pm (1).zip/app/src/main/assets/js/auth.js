// User Authentication Management Module for StudentGig
// Handles Registration, Login, Session Management, Logout, Password Reset

const Auth = {
  // Current user cache
  currentUser: null,
  userProfile: null,

  // Listen to Auth State
  init(onUserReady) {
    if (!auth) {
      console.warn("Auth not initialized yet");
      return;
    }
    auth.onAuthStateChanged(async (user) => {
      if (user) {
        this.currentUser = user;
        try {
          const profile = await DB.getUser(user.uid);
          if (profile && profile.isSuspended) {
            alert("Your account has been suspended by the platform administrator. Please contact support.");
            await this.logout();
            window.location.href = "login.html";
            return;
          }
          this.userProfile = profile;
        } catch (e) {
          console.error("Error loading user profile:", e);
        }
      } else {
        this.currentUser = null;
        this.userProfile = null;
      }
      if (typeof onUserReady === 'function') {
        onUserReady(this.currentUser, this.userProfile);
      }
    });
  },

  // Protect pages that require an authenticated normal user
  requireAuth(redirectPage = "login.html") {
    auth.onAuthStateChanged(async (user) => {
      if (!user) {
        window.location.href = redirectPage;
      } else {
        const profile = await DB.getUser(user.uid);
        if (profile && profile.isSuspended) {
          alert("Account suspended.");
          await this.logout();
          window.location.href = "login.html";
        }
      }
    });
  },

  // Redirect if already logged in (for login.html, register.html)
  redirectIfAuthenticated(destination = "dashboard.html") {
    auth.onAuthStateChanged((user) => {
      if (user) {
        window.location.href = destination;
      }
    });
  },

  // Register New User
  async register({ fullName, username, email, password, confirmPassword, role = 'both', avatarUrl = '' }) {
    // Form Validations
    if (!fullName || fullName.trim().length < 2) {
      throw new Error("Please enter your full name.");
    }
    const cleanUsername = username ? username.trim().toLowerCase() : '';
    if (!cleanUsername || cleanUsername.length < 3 || !/^[a-z0-9_]+$/.test(cleanUsername)) {
      throw new Error("Username must be at least 3 characters and contain only letters, numbers, and underscores.");
    }
    if (password !== confirmPassword) {
      throw new Error("Passwords do not match.");
    }
    if (password.length < 6) {
      throw new Error("Password must be at least 6 characters.");
    }

    // 1. Check for Duplicate Username in Firestore
    const existing = await DB.getUserByUsername(cleanUsername);
    if (existing) {
      throw new Error(`Username @${cleanUsername} is already taken. Please choose another.`);
    }

    // 2. Create Firebase Auth User
    const userCredential = await auth.createUserWithEmailAndPassword(email.trim(), password);
    const user = userCredential.user;

    // 3. Update Display Name
    await user.updateProfile({
      displayName: fullName.trim(),
      photoURL: avatarUrl || ''
    });

    // 4. Send Email Verification
    try {
      await user.sendEmailVerification();
    } catch (e) {
      console.log("Email verification trigger note:", e);
    }

    // 5. Create Profile in Cloud Firestore
    const newProfile = {
      uid: user.uid,
      fullName: fullName.trim(),
      username: cleanUsername,
      email: email.trim().toLowerCase(),
      role: role, // 'client', 'provider', or 'both'
      bio: "Student freelancer on StudentGig Nigeria.",
      skills: [],
      location: "Nigeria",
      avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${cleanUsername}`,
      portfolio: [],
      completedJobs: 0,
      rating: 5.0,
      reviewsCount: 0,
      isSuspended: false,
      isAdmin: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    };

    await DB.updateUser(user.uid, newProfile);

    // 6. Initialize Wallet
    await DB.getWallet(user.uid);

    // 7. Welcome Notification
    await db.collection(DB.NOTIFICATIONS).add({
      userId: user.uid,
      title: "Welcome to StudentGig! 🇳🇬",
      message: `Welcome, ${fullName}! Explore services, publish gigs, post jobs, or earn safely via Moniepoint escrow.`,
      type: "system_welcome",
      read: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    return user;
  },

  // Login
  async login(email, password, remember = true) {
    if (!email || !password) {
      throw new Error("Please enter your email and password.");
    }
    const persistence = remember
      ? firebase.auth.Auth.Persistence.LOCAL
      : firebase.auth.Auth.Persistence.SESSION;
    await auth.setPersistence(persistence);

    try {
      const userCredential = await auth.signInWithEmailAndPassword(email.trim(), password);
      const user = userCredential.user;

      // Check if user is suspended
      const profile = await DB.getUser(user.uid);
      if (profile && profile.isSuspended) {
        await auth.signOut();
        throw new Error("This account has been suspended by the platform administrator.");
      }
      return user;
    } catch (err) {
      // User-friendly error messages
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        throw new Error("Invalid email or password. Please check your credentials.");
      } else if (err.code === 'auth/invalid-email') {
        throw new Error("The email address is badly formatted.");
      } else if (err.code === 'auth/user-disabled') {
        throw new Error("This user account has been disabled.");
      } else {
        throw err;
      }
    }
  },

  // Password Reset
  async sendPasswordReset(email) {
    if (!email || !email.includes('@')) {
      throw new Error("Please provide a valid registered email address.");
    }
    await auth.sendPasswordResetEmail(email.trim());
  },

  // Logout
  async logout() {
    if (auth) {
      await auth.signOut();
    }
  }
};
