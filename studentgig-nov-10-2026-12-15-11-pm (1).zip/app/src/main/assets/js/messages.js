// Real-time Chat & Private Messaging Module for StudentGig

let activeConversationId = null;
let messageListenerUnsubscribe = null;

async function initMessagesPage() {
  Auth.requireAuth("login.html");

  Auth.init(async (user, profile) => {
    if (!user) return;

    // Check if conversation ID or seller target is in URL
    const urlParams = new URLSearchParams(window.location.search);
    const targetUserId = urlParams.get("with");
    const targetName = urlParams.get("name");

    if (targetUserId && targetUserId !== user.uid) {
      // Start or retrieve conversation with target
      const otherUser = { uid: targetUserId, username: targetName || "User" };
      activeConversationId = await DB.getOrCreateConversation(user, otherUser);
    }

    // Listen to all conversations of user
    loadConversationsList(user);

    // If there is an active conversation, open it
    if (activeConversationId) {
      openChatRoom(activeConversationId, user);
    }
  });
}

function loadConversationsList(currentUser) {
  const container = document.getElementById("conversationsList");
  if (!container) return;

  DB.listenConversations(currentUser.uid, (conversations) => {
    if (conversations.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="padding: 24px 10px;">
          <div class="empty-icon" style="font-size: 2rem;">💬</div>
          <div class="empty-title" style="font-size: 1rem;">No conversations</div>
          <div class="empty-desc" style="font-size: 0.8rem;">When you message a client or freelancer, your private chats will appear here.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = conversations.map(c => {
      // Find other participant
      const otherId = c.participants.find(p => p !== currentUser.uid) || currentUser.uid;
      const details = c.participantDetails?.[otherId] || { name: "Student", avatar: "" };
      const isActive = c.id === activeConversationId;

      return `
        <div class="card card-hover" onclick="selectConversation('${c.id}')" style="cursor: pointer; padding: 12px 14px; margin-bottom: 8px; border-left: 4px solid ${isActive ? 'var(--primary)' : 'transparent'}; background: ${isActive ? 'var(--primary-light)' : 'white'};">
          <div style="display: flex; align-items: center; gap: 10px;">
            <img src="${details.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + details.name}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
            <div style="flex: 1; overflow: hidden;">
              <div style="display: flex; justify-content: space-between; align-items: baseline;">
                <div style="font-weight: 700; color: var(--secondary); font-size: 0.95rem;">${details.name}</div>
                <div style="font-size: 0.72rem; color: var(--text-muted);">${formatTimeAgo(c.lastMessageTime)}</div>
              </div>
              <div style="font-size: 0.82rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
                ${c.lastMessage || 'Sent attachment'}
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');
  });
}

function selectConversation(convId) {
  activeConversationId = convId;
  const user = Auth.currentUser;
  if (user) {
    openChatRoom(convId, user);
  }
}

function openChatRoom(convId, currentUser) {
  const chatPane = document.getElementById("chatPaneContainer");
  const messagesList = document.getElementById("chatMessagesList");
  if (!chatPane || !messagesList) return;

  chatPane.style.display = "flex";

  if (messageListenerUnsubscribe) {
    messageListenerUnsubscribe();
  }

  messagesList.innerHTML = `<div class="loading-container"><div class="spinner"></div></div>`;

  messageListenerUnsubscribe = DB.listenMessages(convId, (messages) => {
    if (messages.length === 0) {
      messagesList.innerHTML = `
        <div class="empty-state" style="border: none;">
          <div class="empty-title">Start the conversation</div>
          <div class="empty-desc">Discuss requirements, deadlines, or deliverables.</div>
        </div>
      `;
      return;
    }

    messagesList.innerHTML = messages.map(m => {
      const isSent = m.senderId === currentUser.uid;
      return `
        <div class="message-bubble ${isSent ? 'sent' : 'received'}">
          <div>${escapeHtml(m.text || '')}</div>
          ${m.attachmentUrl ? `
            <img src="${m.attachmentUrl}" class="message-attachment" onclick="window.open('${m.attachmentUrl}', '_blank')" alt="Attachment">
          ` : ''}
          <div class="message-time">${formatTimeAgo(m.createdAt)}</div>
        </div>
      `;
    }).join('');

    // Scroll to bottom
    messagesList.scrollTop = messagesList.scrollHeight;
  });
}

async function handleSendMessage(e) {
  e.preventDefault();
  const input = document.getElementById("chatMessageInput");
  const fileInput = document.getElementById("chatFileInput");
  const user = Auth.currentUser;
  const profile = Auth.userProfile;

  if (!user || !activeConversationId) return;

  const text = input.value.trim();
  let attachmentUrl = null;

  if (fileInput && fileInput.files && fileInput.files[0]) {
    attachmentUrl = await readFileAsDataURL(fileInput.files[0]);
    fileInput.value = "";
  }

  if (!text && !attachmentUrl) return;

  input.value = "";
  await DB.sendMessage(
    activeConversationId,
    user.uid,
    profile?.fullName || user.displayName || "User",
    text,
    attachmentUrl
  );
}

function escapeHtml(text) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
  return text.replace(/[&<>"']/g, m => map[m]);
}
