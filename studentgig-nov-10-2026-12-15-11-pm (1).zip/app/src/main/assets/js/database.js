// Database Service Layer for Cloud Firestore
// Handles all CRUD operations, real-time listeners, and transaction safety

const DB = {
  // Collections
  USERS: 'users',
  WALLETS: 'wallets',
  GIGS: 'gigs',
  JOBS: 'jobs',
  PROPOSALS: 'proposals',
  ORDERS: 'orders',
  CONVERSATIONS: 'conversations',
  MESSAGES: 'messages',
  PAYMENTS: 'payments',
  TRANSACTIONS: 'transactions',
  NOTIFICATIONS: 'notifications',
  REVIEWS: 'reviews',
  REPORTS: 'reports',
  SETTINGS: 'platform_settings',
  ADMIN_LOGS: 'admin_logs',

  // --- Platform Settings ---
  async getPlatformSettings() {
    try {
      const doc = await db.collection(this.SETTINGS).doc('default').get();
      if (doc.exists) {
        return doc.data();
      }
    } catch (e) {
      console.warn("Using default settings fallback:", e);
    }
    // Safe default if not yet seeded
    return {
      moniepointAccountName: "STUDENTGIG NIGERIA ENTERPRISES",
      moniepointBankName: "Moniepoint Microfinance Bank",
      moniepointAccountNumber: "8123456789",
      paymentInstructions: "Transfer the exact fee to the Moniepoint account above via USSD, Mobile App, or Bank Transfer. Note your transaction reference and take a clear screenshot of the debit receipt. Upload it here for administrative confirmation.",
      platformCommission: 5,
      minDeposit: 1000,
      maxDeposit: 500000
    };
  },

  async updatePlatformSettings(data) {
    return db.collection(this.SETTINGS).doc('default').set(data, { merge: true });
  },

  // --- User Profiles ---
  async getUser(uid) {
    const doc = await db.collection(this.USERS).doc(uid).get();
    return doc.exists ? { id: doc.id, ...doc.data() } : null;
  },

  async getUserByUsername(username) {
    const snapshot = await db.collection(this.USERS)
      .where('username', '==', username.toLowerCase().trim())
      .limit(1)
      .get();
    return !snapshot.empty ? snapshot.docs[0].data() : null;
  },

  async updateUser(uid, data) {
    return db.collection(this.USERS).doc(uid).set(data, { merge: true });
  },

  // --- Wallets ---
  async getWallet(uid) {
    const doc = await db.collection(this.WALLETS).doc(uid).get();
    if (doc.exists) {
      return doc.data();
    }
    const initialWallet = {
      uid: uid,
      availableBalance: 0,
      pendingBalance: 0,
      totalEarnings: 0,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    await db.collection(this.WALLETS).doc(uid).set(initialWallet);
    return initialWallet;
  },

  listenWallet(uid, callback) {
    return db.collection(this.WALLETS).doc(uid).onSnapshot(doc => {
      if (doc.exists) {
        callback(doc.data());
      }
    });
  },

  // --- Gigs ---
  async getGigs(category = null, searchQuery = null) {
    let query = db.collection(this.GIGS);
    if (category && category !== 'All') {
      query = query.where('category', '==', category);
    }
    const snapshot = await query.get();
    let gigs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    // Sort client-side to handle complex compound index needs gracefully
    gigs.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));

    if (searchQuery && searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase().trim();
      gigs = gigs.filter(g => 
        (g.title && g.title.toLowerCase().includes(q)) ||
        (g.description && g.description.toLowerCase().includes(q)) ||
        (g.category && g.category.toLowerCase().includes(q)) ||
        (g.sellerName && g.sellerName.toLowerCase().includes(q))
      );
    }
    return gigs;
  },

  async getGigById(gigId) {
    const doc = await db.collection(this.GIGS).doc(gigId).get();
    return doc.exists ? { id: doc.id, ...doc.data() } : null;
  },

  async createGig(gigData) {
    return db.collection(this.GIGS).add({
      ...gigData,
      rating: 5.0,
      reviewsCount: 0,
      isFeatured: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  },

  async deleteGig(gigId) {
    return db.collection(this.GIGS).doc(gigId).delete();
  },

  // --- Jobs ---
  async getJobs(category = null, searchQuery = null) {
    let query = db.collection(this.JOBS);
    if (category && category !== 'All') {
      query = query.where('category', '==', category);
    }
    const snapshot = await query.get();
    let jobs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    jobs.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));

    if (searchQuery && searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase().trim();
      jobs = jobs.filter(j => 
        (j.title && j.title.toLowerCase().includes(q)) ||
        (j.description && j.description.toLowerCase().includes(q)) ||
        (j.category && j.category.toLowerCase().includes(q))
      );
    }
    return jobs;
  },

  async getJobById(jobId) {
    const doc = await db.collection(this.JOBS).doc(jobId).get();
    return doc.exists ? { id: doc.id, ...doc.data() } : null;
  },

  async createJob(jobData) {
    return db.collection(this.JOBS).add({
      ...jobData,
      status: 'open',
      proposalsCount: 0,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  },

  // --- Proposals ---
  async submitProposal(proposalData) {
    const ref = await db.collection(this.PROPOSALS).add({
      ...proposalData,
      status: 'Pending',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    // Increment job proposal count
    await db.collection(this.JOBS).doc(proposalData.jobId).update({
      proposalsCount: firebase.firestore.FieldValue.increment(1)
    });
    return ref;
  },

  async getProposalsForJob(jobId) {
    const snapshot = await db.collection(this.PROPOSALS)
      .where('jobId', '==', jobId)
      .get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  },

  async getMyProposals(freelancerId) {
    const snapshot = await db.collection(this.PROPOSALS)
      .where('freelancerId', '==', freelancerId)
      .get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  },

  async updateProposalStatus(proposalId, newStatus) {
    return db.collection(this.PROPOSALS).doc(proposalId).update({
      status: newStatus,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  },

  // --- Payments (Moniepoint Submissions) ---
  async submitPayment(paymentData) {
    const submissionTime = new Date();
    // 24-hour review deadline calculation
    const reviewDeadline = new Date(submissionTime.getTime() + 24 * 60 * 60 * 1000);

    return db.collection(this.PAYMENTS).add({
      ...paymentData,
      status: 'Pending Review',
      submissionTime: firebase.firestore.Timestamp.fromDate(submissionTime),
      reviewDeadline: firebase.firestore.Timestamp.fromDate(reviewDeadline),
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  },

  async getUserPayments(userId) {
    const snapshot = await db.collection(this.PAYMENTS)
      .where('userId', '==', userId)
      .get();
    let payments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    payments.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    return payments;
  },

  // --- Admin Payment Actions ---
  async getAdminPayments(filterStatus = null) {
    let query = db.collection(this.PAYMENTS);
    if (filterStatus && filterStatus !== 'All') {
      query = query.where('status', '==', filterStatus);
    }
    const snapshot = await query.get();
    let list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    list.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    return list;
  },

  async approvePayment(paymentId, adminEmail) {
    const paymentRef = db.collection(this.PAYMENTS).doc(paymentId);
    const paymentDoc = await paymentRef.get();
    if (!paymentDoc.exists) throw new Error("Payment record not found");
    
    const p = paymentDoc.data();
    if (p.status === 'Approved') throw new Error("Payment has already been approved");

    const amount = Number(p.amount) || 0;
    const userId = p.userId;

    // Run as atomic batch
    const batch = db.batch();

    // 1. Mark payment approved
    batch.update(paymentRef, {
      status: 'Approved',
      reviewedBy: adminEmail,
      reviewedAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // 2. Credit User Wallet
    const walletRef = db.collection(this.WALLETS).doc(userId);
    batch.set(walletRef, {
      availableBalance: firebase.firestore.FieldValue.increment(amount),
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    // 3. Create Transaction Record
    const transRef = db.collection(this.TRANSACTIONS).doc();
    batch.set(transRef, {
      userId: userId,
      type: 'deposit',
      amount: amount,
      status: 'completed',
      description: `Moniepoint Deposit Verified (Ref: ${p.transactionRef})`,
      reference: p.transactionRef,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // 4. Create Notification
    const notifRef = db.collection(this.NOTIFICATIONS).doc();
    batch.set(notifRef, {
      userId: userId,
      title: "Payment Approved! 🎉",
      message: `Your deposit of ₦${amount.toLocaleString()} has been verified and added to your wallet.`,
      type: "payment_approved",
      read: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // 5. Admin Audit Log
    const logRef = db.collection(this.ADMIN_LOGS).doc();
    batch.set(logRef, {
      adminEmail: adminEmail,
      action: "APPROVE_PAYMENT",
      targetId: paymentId,
      details: `Approved ₦${amount} for user ${p.userName} (${userId})`,
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    });

    await batch.commit();
  },

  async rejectPayment(paymentId, rejectionReason, adminEmail) {
    if (!rejectionReason || rejectionReason.trim() === '') {
      throw new Error("A rejection reason is required.");
    }
    const paymentRef = db.collection(this.PAYMENTS).doc(paymentId);
    const paymentDoc = await paymentRef.get();
    if (!paymentDoc.exists) throw new Error("Payment record not found");
    const p = paymentDoc.data();

    const batch = db.batch();

    batch.update(paymentRef, {
      status: 'Rejected',
      rejectionReason: rejectionReason,
      reviewedBy: adminEmail,
      reviewedAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    const notifRef = db.collection(this.NOTIFICATIONS).doc();
    batch.set(notifRef, {
      userId: p.userId,
      title: "Payment Submission Rejected",
      message: `Your payment of ₦${Number(p.amount).toLocaleString()} could not be verified: "${rejectionReason}". You may resubmit with a valid receipt.`,
      type: "payment_rejected",
      read: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    const logRef = db.collection(this.ADMIN_LOGS).doc();
    batch.set(logRef, {
      adminEmail: adminEmail,
      action: "REJECT_PAYMENT",
      targetId: paymentId,
      details: `Rejected payment ${paymentId}: ${rejectionReason}`,
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    });

    await batch.commit();
  },

  // --- Transactions ---
  async getUserTransactions(userId) {
    const snapshot = await db.collection(this.TRANSACTIONS)
      .where('userId', '==', userId)
      .get();
    let trans = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    trans.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    return trans;
  },

  // --- Notifications ---
  listenNotifications(userId, callback) {
    return db.collection(this.NOTIFICATIONS)
      .where('userId', '==', userId)
      .onSnapshot(snapshot => {
        let notifs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        notifs.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
        callback(notifs);
      });
  },

  async markNotificationRead(notifId) {
    return db.collection(this.NOTIFICATIONS).doc(notifId).update({ read: true });
  },

  // --- Messaging ---
  async getOrCreateConversation(user1, user2) {
    const sortedIds = [user1.uid, user2.uid].sort();
    const convId = sortedIds.join('_');
    const convRef = db.collection(this.CONVERSATIONS).doc(convId);
    const doc = await convRef.get();

    if (!doc.exists) {
      await convRef.set({
        id: convId,
        participants: sortedIds,
        participantDetails: {
          [user1.uid]: { name: user1.fullName || user1.username, avatar: user1.avatarUrl || '' },
          [user2.uid]: { name: user2.fullName || user2.username, avatar: user2.avatarUrl || '' }
        },
        lastMessage: "Conversation started",
        lastMessageTime: firebase.firestore.FieldValue.serverTimestamp(),
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    }
    return convId;
  },

  listenConversations(userId, callback) {
    return db.collection(this.CONVERSATIONS)
      .where('participants', 'array-contains', userId)
      .onSnapshot(snapshot => {
        let list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        list.sort((a, b) => (b.lastMessageTime?.seconds || 0) - (a.lastMessageTime?.seconds || 0));
        callback(list);
      });
  },

  listenMessages(conversationId, callback) {
    return db.collection(this.MESSAGES)
      .where('conversationId', '==', conversationId)
      .onSnapshot(snapshot => {
        let list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        list.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0));
        callback(list);
      });
  },

  async sendMessage(conversationId, senderId, senderName, text, attachmentUrl = null) {
    const batch = db.batch();
    const msgRef = db.collection(this.MESSAGES).doc();
    batch.set(msgRef, {
      conversationId: conversationId,
      senderId: senderId,
      senderName: senderName,
      text: text,
      attachmentUrl: attachmentUrl,
      read: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    const convRef = db.collection(this.CONVERSATIONS).doc(conversationId);
    batch.update(convRef, {
      lastMessage: text || "Sent an attachment",
      lastMessageTime: firebase.firestore.FieldValue.serverTimestamp()
    });

    await batch.commit();
  }
};
