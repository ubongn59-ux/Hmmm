// Gigs Marketplace Controller for StudentGig

const GIG_CATEGORIES = [
  "All",
  "Graphic Design",
  "Web Development",
  "Writing",
  "Video Editing",
  "Programming",
  "Social Media Management",
  "Data Entry",
  "Tutoring",
  "Digital Marketing",
  "Content Creation",
  "Virtual Assistance",
  "Other Services"
];

let currentSelectedCategory = "All";
let allGigsCache = [];

// Initialize Marketplace on explore.html or index.html
async function initExplorePage() {
  renderCategoryChips();
  await loadExploreGigs();

  // Search input listener
  const searchInput = document.getElementById("gigSearchInput");
  if (searchInput) {
    searchInput.addEventListener("input", debounce(() => {
      filterAndRenderGigs();
    }, 300));
  }

  // Price filter listener
  const priceSelect = document.getElementById("priceSortSelect");
  if (priceSelect) {
    priceSelect.addEventListener("change", () => {
      filterAndRenderGigs();
    });
  }
}

function renderCategoryChips() {
  const container = document.getElementById("categoryChipsContainer");
  if (!container) return;

  container.innerHTML = GIG_CATEGORIES.map(cat => `
    <button class="category-chip ${cat === currentSelectedCategory ? 'active' : ''}" onclick="selectCategory('${cat}', this)">
      ${cat}
    </button>
  `).join('');
}

function selectCategory(cat, el) {
  currentSelectedCategory = cat;
  document.querySelectorAll(".category-chip").forEach(c => c.classList.remove("active"));
  if (el) el.classList.add("active");
  filterAndRenderGigs();
}

async function loadExploreGigs() {
  const container = document.getElementById("exploreGigsGrid");
  if (!container) return;

  container.innerHTML = `
    <div class="loading-container" style="grid-column: 1 / -1;">
      <div class="spinner"></div>
      <div>Loading marketplace services...</div>
    </div>
  `;

  try {
    allGigsCache = await DB.getGigs();
    filterAndRenderGigs();
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error" style="grid-column: 1/-1;">Could not load gigs. Check internet connection.</div>`;
  }
}

function filterAndRenderGigs() {
  const container = document.getElementById("exploreGigsGrid");
  if (!container) return;

  const searchVal = document.getElementById("gigSearchInput")?.value?.toLowerCase().trim() || "";
  const priceSort = document.getElementById("priceSortSelect")?.value || "default";

  let filtered = [...allGigsCache];

  // Category filter
  if (currentSelectedCategory !== "All") {
    filtered = filtered.filter(g => g.category === currentSelectedCategory);
  }

  // Text search
  if (searchVal) {
    filtered = filtered.filter(g => 
      (g.title && g.title.toLowerCase().includes(searchVal)) ||
      (g.description && g.description.toLowerCase().includes(searchVal)) ||
      (g.sellerName && g.sellerName.toLowerCase().includes(searchVal))
    );
  }

  // Price Sort
  if (priceSort === "low") {
    filtered.sort((a, b) => Number(a.price) - Number(b.price));
  } else if (priceSort === "high") {
    filtered.sort((a, b) => Number(b.price) - Number(a.price));
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🔍</div>
        <div class="empty-title">No gigs found</div>
        <div class="empty-desc">No services match your selected category or search keyword.</div>
        <button class="btn btn-outline btn-sm" onclick="selectCategory('All')">Clear Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(gig => `
    <div class="gig-card" onclick="window.location.href='gig-details.html?id=${gig.id}'" style="cursor: pointer;">
      <div style="position: relative;">
        ${gig.imageUrl ? `
          <img src="${gig.imageUrl}" class="gig-thumbnail" alt="${gig.title}" onerror="this.src='https://picsum.photos/seed/${gig.id}/400/250'">
        ` : `
          <div class="gig-thumbnail-fallback">🎨</div>
        `}
        <span class="gig-category-badge">${gig.category || 'Service'}</span>
      </div>
      <div class="gig-body">
        <div class="gig-seller-row">
          <img src="${gig.sellerAvatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + (gig.sellerName || 'user')}" class="gig-seller-avatar" alt="${gig.sellerName}">
          <span class="gig-seller-name">@${gig.sellerName || 'student'}</span>
        </div>
        <h3 class="gig-title">${gig.title}</h3>
        <div class="gig-footer">
          <div class="gig-rating">★ ${Number(gig.rating || 5.0).toFixed(1)} <span style="color:#94a3b8;font-weight:normal;">(${gig.reviewsCount || 0})</span></div>
          <div class="gig-price-box">
            <div class="gig-price-label">Starting at</div>
            <div class="gig-price">${formatNaira(gig.price)}</div>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

// Handle Create Gig Form
async function handleCreateGigSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("createGigSubmitBtn");
  const alertBox = document.getElementById("createGigAlert");
  alertBox.innerHTML = "";

  const user = Auth.currentUser;
  const profile = Auth.userProfile;
  if (!user) {
    alert("Please log in to publish a gig.");
    window.location.href = "login.html";
    return;
  }

  const title = document.getElementById("gigTitle").value.trim();
  const category = document.getElementById("gigCategory").value;
  const description = document.getElementById("gigDescription").value.trim();
  const price = Number(document.getElementById("gigPrice").value);
  const deliveryDays = Number(document.getElementById("gigDeliveryDays").value);
  const imageInput = document.getElementById("gigImageInput");

  if (!title || title.length < 5) {
    alertBox.innerHTML = `<div class="alert alert-error">Please provide a descriptive gig title (min 5 chars).</div>`;
    return;
  }
  if (!category || category === "") {
    alertBox.innerHTML = `<div class="alert alert-error">Please select a service category.</div>`;
    return;
  }
  if (!price || price < 500) {
    alertBox.innerHTML = `<div class="alert alert-error">Minimum gig price in Nigeria is ₦500.</div>`;
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Publishing Gig...`;

  try {
    let imageUrl = "";
    // If user uploaded an image
    if (imageInput && imageInput.files && imageInput.files[0]) {
      const file = imageInput.files[0];
      // Convert image to Base64 or upload to Storage
      imageUrl = await readFileAsDataURL(file);
    } else {
      imageUrl = `https://picsum.photos/seed/${encodeURIComponent(title)}/600/400`;
    }

    const newGig = {
      sellerId: user.uid,
      sellerName: profile?.username || user.displayName || "student",
      sellerFullName: profile?.fullName || user.displayName || "Student",
      sellerAvatar: profile?.avatarUrl || "",
      title: title,
      category: category,
      description: description,
      price: price,
      deliveryDays: deliveryDays || 3,
      imageUrl: imageUrl
    };

    const docRef = await DB.createGig(newGig);
    window.location.href = `gig-details.html?id=${docRef.id}`;
  } catch (err) {
    alertBox.innerHTML = `<div class="alert alert-error">Error publishing gig: ${err.message}</div>`;
    btn.disabled = false;
    btn.innerHTML = `Publish Gig`;
  }
}

// Utility: Read File as Data URL
function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}
