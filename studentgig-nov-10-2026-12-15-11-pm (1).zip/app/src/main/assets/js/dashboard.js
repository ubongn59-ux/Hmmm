// User Dashboard Controller for StudentGig

document.addEventListener("DOMContentLoaded", () => {
  Auth.init(async (user, profile) => {
    if (!user) {
      window.location.href = "login.html";
      return;
    }
    renderDashboard(user, profile);
  });
});

async function renderDashboard(user, profile) {
  // Update Header & Greeting
  const nameEl = document.getElementById("dashUserName");
  const avatarEl = document.getElementById("dashUserAvatar");
  const roleEl = document.getElementById("dashUserRole");

  if (nameEl) nameEl.textContent = profile?.fullName || user.displayName || "Student";
  if (avatarEl) {
    if (profile?.avatarUrl) {
      avatarEl.src = profile.avatarUrl;
    } else {
      avatarEl.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username || 'user'}`;
    }
  }
  if (roleEl) {
    const roleMap = {
      client: "Client / Hirer",
      provider: "Service Provider",
      both: "Freelancer & Client"
    };
    roleEl.textContent = roleMap[profile?.role] || "Member";
  }

  // Real-time Wallet Listener
  DB.listenWallet(user.uid, (wallet) => {
    const balanceEl = document.getElementById("dashWalletBalance");
    const earningsEl = document.getElementById("dashTotalEarnings");
    if (balanceEl) balanceEl.textContent = formatNaira(wallet.availableBalance || 0);
    if (earningsEl) earningsEl.textContent = formatNaira(wallet.totalEarnings || 0);
  });

  // Load Dashboard Counts
  loadDashboardMetrics(user.uid);

  // Load Recent Gigs & Jobs
  loadRecentMarketplace();

  // Load Unread Notifications
  DB.listenNotifications(user.uid, (notifs) => {
    const unread = notifs.filter(n => !n.read).length;
    const badge = document.getElementById("notifBadge");
    if (badge) {
      if (unread > 0) {
        badge.style.display = "flex";
        badge.textContent = unread > 9 ? "9+" : unread;
      } else {
        badge.style.display = "none";
      }
    }
  });
}

async function loadDashboardMetrics(uid) {
  try {
    // Active / Completed Jobs
    const myProposals = await DB.getMyProposals(uid);
    const activeJobs = myProposals.filter(p => p.status === 'Accepted').length;
    const completedJobs = myProposals.filter(p => p.status === 'Completed').length;
    
    const activeJobsEl = document.getElementById("dashActiveJobs");
    const completedJobsEl = document.getElementById("dashCompletedJobs");
    if (activeJobsEl) activeJobsEl.textContent = activeJobs;
    if (completedJobsEl) completedJobsEl.textContent = completedJobs;

    // Pending Payments
    const payments = await DB.getUserPayments(uid);
    const pendingPayments = payments.filter(p => p.status === 'Pending Review').length;
    const pendingOrdersEl = document.getElementById("dashPendingOrders");
    if (pendingOrdersEl) pendingOrdersEl.textContent = pendingPayments;
  } catch (err) {
    console.error("Dashboard metrics load error:", err);
  }
}

async function loadRecentMarketplace() {
  const gigsContainer = document.getElementById("dashRecentGigs");
  if (!gigsContainer) return;

  try {
    const gigs = await DB.getGigs();
    if (gigs.length === 0) {
      gigsContainer.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon">🎒</div>
          <div class="empty-title">No gigs available yet</div>
          <div class="empty-desc">Be the first student to publish a freelance service!</div>
          <a href="create-gig.html" class="btn btn-primary btn-sm">Post a Gig</a>
        </div>
      `;
      return;
    }

    gigsContainer.innerHTML = gigs.slice(0, 6).map(gig => `
      <div class="gig-card" onclick="window.location.href='gig-details.html?id=${gig.id}'" style="cursor: pointer;">
        ${gig.imageUrl ? `
          <img src="${gig.imageUrl}" class="gig-thumbnail" alt="${gig.title}" onerror="this.src='https://picsum.photos/seed/${gig.id}/400/250'">
        ` : `
          <div class="gig-thumbnail-fallback">⚡</div>
        `}
        <div class="gig-body">
          <div class="gig-seller-row">
            <img src="${gig.sellerAvatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + (gig.sellerName || 'user')}" class="gig-seller-avatar" alt="${gig.sellerName}">
            <span class="gig-seller-name">@${gig.sellerName || 'student'}</span>
          </div>
          <h3 class="gig-title">${gig.title}</h3>
          <div class="gig-footer">
            <div class="gig-rating">★ ${Number(gig.rating || 5.0).toFixed(1)} <span style="color:#94a3b8;font-weight:normal;">(${gig.reviewsCount || 0})</span></div>
            <div class="gig-price-box">
              <div class="gig-price-label">Starting at</div>
              <div class="gig-price">${formatNaira(gig.price)}</div>
            </div>
          </div>
        </div>
      </div>
    `).join('');
  } catch (err) {
    gigsContainer.innerHTML = `<div class="alert alert-error">Failed to load gigs.</div>`;
  }
}
