// StudentGig Progressive Web App Service Worker
const CACHE_NAME = 'studentgig-v1';
const ASSETS_TO_CACHE = [
  '/',
  'index.html',
  'login.html',
  'register.html',
  'dashboard.html',
  'explore.html',
  'gig-details.html',
  'create-gig.html',
  'jobs.html',
  'post-job.html',
  'messages.html',
  'profile.html',
  'wallet.html',
  'payments.html',
  'notifications.html',
  'css/style.css',
  'css/dashboard.css',
  'css/animations.css',
  'css/admin.css',
  'css/responsive.css',
  'js/firebase-config.js',
  'js/database.js',
  'js/auth.js',
  'js/animations.js',
  'manifest.json'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(err => {
        console.warn("Service worker cache error:", err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((k) => {
          if (k !== CACHE_NAME) {
            return caches.delete(k);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  // Network first with cache fallback
  e.respondWith(
    fetch(e.request).catch(() => {
      return caches.match(e.request);
    })
  );
});
